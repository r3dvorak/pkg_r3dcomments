<?php
/**
 * @package     mod_r3dcomments
 * @version     6.1.10
 * @copyright   Copyright (C) 2025. All rights reserved.
 * @license     GNU GPL v2 or later
 * @author      Richard Dvořák, <dev@r3d.de> - https://r3d.de
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;

$context = $displayData['context'] ?? 'com_content.article';
$itemId  = (int) ($displayData['item_id'] ?? 0);

if (!$itemId) {
    return;
}

$app  = Factory::getApplication();
$user = $app->getIdentity();

try {
    /** @var \Joomla\Component\R3dcomments\Site\Extension\R3dcommentsComponent $component */
    $component  = $app->bootComponent('com_r3dcomments');
    $mvcFactory = $component->getMVCFactory();

    /** @var \Joomla\Component\R3dcomments\Site\Model\CommentsModel $commentsModel */
    $commentsModel = $mvcFactory->createModel('Comments', 'Site', ['ignore_request' => true]);
    $commentsModel->setState('filter.context', $context);
    $commentsModel->setState('filter.item_id',  $itemId);
    $items = $commentsModel->getItems();

    /** @var \Joomla\Component\R3dcomments\Site\Model\CommentModel $commentModel */
    $commentModel = $mvcFactory->createModel('Comment', 'Site', ['ignore_request' => true]);
    $form         = $commentModel->getForm();
} catch (\Throwable $e) {
    if ($app->isClient('administrator')) {
        $app->enqueueMessage('R3D Comments module error: ' . $e->getMessage(), 'error');
    }

    return;
}

$canEditComment = function ($comment) use ($user): bool {
    if (!$user || !$user->id) {
        return false;
    }

    if ($user->authorise('core.edit', 'com_r3dcomments')) {
        return true;
    }

    if (
        (int) $comment->created_by === (int) $user->id
        && $user->authorise('core.edit.own', 'com_r3dcomments')
    ) {
        return true;
    }

    return false;
};

static $r3dcommentsInlineStylesPrinted = false;

?>
<div class="r3dcomments-wrapper r3dcomments-wrapper-standard">
    <?php if (!$r3dcommentsInlineStylesPrinted) : ?>
        <style>
            .r3dcomments-wrapper-uikit .r3dcomment-children,
            .r3dcomments-wrapper-standard .r3dcomment-children {
                margin-top: 1rem;
                margin-left: 1.5rem;
                padding-left: 1rem;
                border-left: 3px solid rgba(0, 0, 0, 0.12);
            }

            .r3dcomments-wrapper-uikit .r3dcomment-item-child,
            .r3dcomments-wrapper-standard .r3dcomment-item-child {
                margin-bottom: 0.75rem;
                background: rgba(0, 0, 0, 0.02);
            }

            .r3dcomments-wrapper-uikit .r3dcomment-item-child:last-child,
            .r3dcomments-wrapper-standard .r3dcomment-item-child:last-child {
                margin-bottom: 0;
            }

            .r3dcomments-wrapper-uikit .r3dcomment-meta,
            .r3dcomments-wrapper-uikit .r3dcomment-actions,
            .r3dcomments-wrapper-uikit .r3dcomment-body,
            .r3dcomments-wrapper-standard .r3dcomment-meta,
            .r3dcomments-wrapper-standard .r3dcomment-actions,
            .r3dcomments-wrapper-standard .r3dcomment-body,
            .r3dcomments-wrapper-standard .r3dcomment-field,
            .r3dcomments-wrapper-standard .r3dcomment-reply-indicator {
                margin-bottom: 0.75rem;
            }

            .r3dcomments-wrapper-uikit .r3dcomment-meta:last-child,
            .r3dcomments-wrapper-uikit .r3dcomment-actions:last-child,
            .r3dcomments-wrapper-uikit .r3dcomment-body:last-child,
            .r3dcomments-wrapper-standard .r3dcomment-meta:last-child,
            .r3dcomments-wrapper-standard .r3dcomment-actions:last-child,
            .r3dcomments-wrapper-standard .r3dcomment-body:last-child,
            .r3dcomments-wrapper-standard .r3dcomment-field:last-child,
            .r3dcomments-wrapper-standard .r3dcomment-reply-indicator:last-child {
                margin-bottom: 0;
            }

            .r3dcomments-wrapper-standard .r3dcomment-item {
                margin: 0 0 1.25rem;
                padding: 1rem;
                border: 1px solid rgba(0, 0, 0, 0.12);
                border-radius: 0.5rem;
                background: #fff;
            }

            .r3dcomments-wrapper-standard .r3dcomment-reply-indicator {
                padding: 0.75rem 1rem;
                border-left: 3px solid #0d6efd;
                background: rgba(13, 110, 253, 0.08);
            }

            .r3dcomments-wrapper-standard #r3dcomment-form button {
                margin-top: 0.5rem;
            }
        </style>
        <?php $r3dcommentsInlineStylesPrinted = true; ?>
    <?php endif; ?>
    <h3><?php echo Text::_('COM_R3DCOMMENTS_COMMENTS_HEADING'); ?></h3>

    <?php if (!empty($items)) : ?>
        <?php foreach ($items as $root) : ?>
            <article class="r3dcomment-item">
                <header class="r3dcomment-meta">
                    <strong><?php echo htmlspecialchars($root->author_name ?: $root->user_id, ENT_QUOTES, 'UTF-8'); ?></strong>
                    <span> | <?php echo $root->created; ?></span>

                    <?php if ($canEditComment($root)) : ?>
                        <a href="<?php echo Route::_('index.php?option=com_r3dcomments&task=comment.edit&id=' . (int) $root->id); ?>">
                            <?php echo Text::_('JEDIT'); ?>
                        </a>
                    <?php endif; ?>
                </header>

                <div class="r3dcomment-body">
                    <?php echo $root->comment; ?>
                </div>

                <div class="r3dcomment-actions">
                    <a href="#"
                       class="r3d-reply-btn"
                       data-parent="<?php echo (int) $root->id; ?>"
                       data-quote="<?php echo htmlspecialchars(strip_tags($root->comment), ENT_QUOTES, 'UTF-8'); ?>">
                        ↳ <?php echo Text::_('COM_R3DCOMMENTS_REPLY'); ?>
                    </a>
                </div>

                <?php if (!empty($root->children)) : ?>
                    <div class="r3dcomment-children">
                        <?php foreach ($root->children as $child) : ?>
                            <article class="r3dcomment-item r3dcomment-item-child">
                                <header class="r3dcomment-meta">
                                    <strong><?php echo htmlspecialchars($child->author_name ?: $child->user_id, ENT_QUOTES, 'UTF-8'); ?></strong>
                                    <span> | <?php echo $child->created; ?></span>

                                    <?php if ($canEditComment($child)) : ?>
                                        <a href="<?php echo Route::_('index.php?option=com_r3dcomments&task=comment.edit&id=' . (int) $child->id); ?>">
                                            <?php echo Text::_('JEDIT'); ?>
                                        </a>
                                    <?php endif; ?>
                                </header>

                                <div class="r3dcomment-body">
                                    <?php echo $child->comment; ?>
                                </div>

                                <div class="r3dcomment-actions">
                                    <a href="#"
                                       class="r3d-reply-btn"
                                       data-parent="<?php echo (int) $root->id; ?>"
                                       data-quote="<?php echo htmlspecialchars(strip_tags($child->comment), ENT_QUOTES, 'UTF-8'); ?>">
                                        ↳ <?php echo Text::_('COM_R3DCOMMENTS_REPLY'); ?>
                                    </a>
                                </div>
                            </article>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </article>
        <?php endforeach; ?>
    <?php else : ?>
        <p><?php echo Text::_('COM_R3DCOMMENTS_NO_COMMENTS'); ?></p>
    <?php endif; ?>

    <?php if ($form) : ?>
        <div class="r3dcomment-form-wrap">
            <h4><?php echo Text::_('COM_R3DCOMMENTS_WRITE_COMMENT'); ?></h4>

            <div id="r3d-reply-indicator"
                 class="r3dcomment-reply-indicator"
                 style="display:none;">
                <strong><?php echo Text::_('COM_R3DCOMMENTS_REPLY_TO_COMMENT'); ?></strong>
                <div id="r3d-reply-preview"></div>
                <a href="#" id="r3d-reply-cancel">
                    <?php echo Text::_('JCANCEL'); ?>
                </a>
            </div>

            <form action="<?php echo Uri::root(); ?>index.php?option=com_r3dcomments&task=comment.save"
                  method="post"
                  id="r3dcomment-form">

                <?php foreach ($form->getFieldset('frontend') as $field) : ?>
                    <?php if (($field->fieldname === 'author_name' || $field->fieldname === 'author_email') && !$user->guest) {
                        continue;
                    } ?>
                    <div class="r3dcomment-field">
                        <?php echo $field->renderField(); ?>
                    </div>
                <?php endforeach; ?>

                <input type="hidden" name="jform[item_id]" value="<?php echo (int) $itemId; ?>">
                <input type="hidden" name="jform[context]" value="<?php echo htmlspecialchars($context, ENT_QUOTES, 'UTF-8'); ?>">
                <input type="hidden" name="jform[parent_id]" id="r3d-parent" value="0">
                <input type="hidden" name="jform[quoted_comment_id]" id="r3d-quote-id" value="0">
                <input type="hidden" name="jform[quoted_comment_text]" id="r3d-quote-text" value="">
                <input type="hidden" name="jform[state]" value="1">

                <button type="submit">
                    <?php echo Text::_('COM_R3DCOMMENTS_SUBMIT'); ?>
                </button>

                <?php echo HTMLHelper::_('form.token'); ?>
            </form>
        </div>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const replyBox = document.getElementById('r3d-reply-indicator');
    const replyPreview = document.getElementById('r3d-reply-preview');
    const cancelBtn = document.getElementById('r3d-reply-cancel');
    const parentField = document.getElementById('r3d-parent');
    const quoteIdField = document.getElementById('r3d-quote-id');
    const quoteTxtField = document.getElementById('r3d-quote-text');

    document.querySelectorAll('.r3d-reply-btn').forEach((btn) => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();

            const parentId = btn.dataset.parent;
            const quote = btn.dataset.quote;

            parentField.value = parentId;
            quoteIdField.value = parentId;
            quoteTxtField.value = quote;

            replyPreview.innerText = quote;
            replyBox.style.display = 'block';

            document.getElementById('r3dcomment-form').scrollIntoView({ behavior: 'smooth' });
        });
    });

    if (cancelBtn) {
        cancelBtn.addEventListener('click', (e) => {
            e.preventDefault();

            parentField.value = 0;
            quoteIdField.value = 0;
            quoteTxtField.value = '';

            replyPreview.innerText = '';
            replyBox.style.display = 'none';
        });
    }
});
</script>
