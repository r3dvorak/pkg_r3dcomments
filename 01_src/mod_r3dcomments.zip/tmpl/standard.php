<?php
/**
 * @package     mod_r3dcomments
 * @version     6.1.10
 * @copyright   Copyright (C) 2025. All rights reserved.
 * @license     GNU GPL v2 or later
 * @author      Richard Dvořák, <dev@r3d.de> - https://r3d.de
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;

$context = $displayData['context'] ?? 'com_content.article';
$itemId  = (int) ($displayData['item_id'] ?? 0);

if (!$itemId) {
    return;
}

$app  = Factory::getApplication();
$user = $app->getIdentity();
$isEnglish = str_starts_with(strtolower((string) Factory::getLanguage()->getTag()), 'en');
$translateFallback = static function (string $key, string $de, string $en) use ($isEnglish): string {
    $text = Text::_($key);

    return $text !== $key ? $text : ($isEnglish ? $en : $de);
};

try {
    /** @var \Joomla\Component\R3dcomments\Site\Extension\R3dcommentsComponent $component */
    $component  = $app->bootComponent('com_r3dcomments');
    $mvcFactory = $component->getMVCFactory();

    /** @var \Joomla\Component\R3dcomments\Site\Model\CommentsModel $commentsModel */
    $commentsModel = $mvcFactory->createModel('Comments', 'Site', ['ignore_request' => true]);
    $commentsModel->setState('filter.context', $context);
    $commentsModel->setState('filter.item_id',  $itemId);
    $items = $commentsModel->getItems();

    /** @var \Joomla\Component\R3dcomments\Site\Model\CommentModel $commentModel */
    $commentModel = $mvcFactory->createModel('Comment', 'Site', ['ignore_request' => true]);
    $form         = $commentModel->getForm();
} catch (\Throwable $e) {
    if ($app->isClient('administrator')) {
        $app->enqueueMessage('R3D Comments module error: ' . $e->getMessage(), 'error');
    }

    return;
}

$canEditComment = function ($comment) use ($user): bool {
    if (!$user || !$user->id) {
        return false;
    }

    if ($user->authorise('core.edit', 'com_r3dcomments')) {
        return true;
    }

    if (
        (int) $comment->created_by === (int) $user->id
        && $user->authorise('core.edit.own', 'com_r3dcomments')
    ) {
        return true;
    }

    return false;
};

static $r3dcommentsInlineStylesPrinted = false;

?>
<div class="r3dcomments-wrapper r3dcomments-wrapper-standard">
    <?php if (!$r3dcommentsInlineStylesPrinted) : ?>
        <style>
            .r3dcomments-wrapper-uikit .r3dcomment-form-wrap,
            .r3dcomments-wrapper-standard .r3dcomment-form-wrap {
                margin-top: 2.5rem;
                padding-top: 1.75rem;
                border-top: 1px solid rgba(0, 0, 0, 0.12);
            }

            .r3dcomments-wrapper-uikit .r3dcomment-children,
            .r3dcomments-wrapper-standard .r3dcomment-children {
                margin-top: 1rem;
                margin-left: 1.5rem;
                padding-left: 1rem;
                border-left: 3px solid rgba(0, 0, 0, 0.12);
            }

            .r3dcomments-wrapper-uikit .r3dcomment-item-child,
            .r3dcomments-wrapper-standard .r3dcomment-item-child {
                margin-bottom: 0.75rem;
                background: rgba(0, 0, 0, 0.02);
            }

            .r3dcomments-wrapper-uikit .r3dcomment-item-root,
            .r3dcomments-wrapper-standard .r3dcomment-item-root {
                margin-bottom: 2rem;
            }

            .r3dcomments-wrapper-uikit .r3dcomment-item-child:last-child,
            .r3dcomments-wrapper-standard .r3dcomment-item-child:last-child {
                margin-bottom: 0;
            }

            .r3dcomments-wrapper-uikit .r3dcomment-meta,
            .r3dcomments-wrapper-uikit .r3dcomment-actions,
            .r3dcomments-wrapper-uikit .r3dcomment-body,
            .r3dcomments-wrapper-standard .r3dcomment-meta,
            .r3dcomments-wrapper-standard .r3dcomment-actions,
            .r3dcomments-wrapper-standard .r3dcomment-body,
            .r3dcomments-wrapper-standard .r3dcomment-field,
            .r3dcomments-wrapper-standard .r3dcomment-reply-indicator {
                margin-bottom: 0.75rem;
            }

            .r3dcomments-wrapper-uikit .r3dcomment-meta:last-child,
            .r3dcomments-wrapper-uikit .r3dcomment-actions:last-child,
            .r3dcomments-wrapper-uikit .r3dcomment-body:last-child,
            .r3dcomments-wrapper-standard .r3dcomment-meta:last-child,
            .r3dcomments-wrapper-standard .r3dcomment-actions:last-child,
            .r3dcomments-wrapper-standard .r3dcomment-body:last-child,
            .r3dcomments-wrapper-standard .r3dcomment-field:last-child,
            .r3dcomments-wrapper-standard .r3dcomment-reply-indicator:last-child {
                margin-bottom: 0;
            }

            .r3dcomments-wrapper-uikit .r3dcomment-actions,
            .r3dcomments-wrapper-standard .r3dcomment-actions {
                margin-top: 1rem;
            }

            .r3dcomments-wrapper-uikit .r3d-reply-btn,
            .r3dcomments-wrapper-standard .r3d-reply-btn {
                display: inline-flex;
                align-items: center;
                gap: 0.35rem;
                padding: 0.45rem 0.85rem;
                border: 1px solid rgba(13, 110, 253, 0.28);
                border-radius: 999px;
                background: rgba(13, 110, 253, 0.08);
                color: #0b5ed7;
                font-size: 0.95rem;
                font-weight: 600;
                line-height: 1.2;
                text-decoration: none;
                transition: background 0.15s ease, border-color 0.15s ease, color 0.15s ease;
            }

            .r3dcomments-wrapper-uikit .r3d-reply-btn:hover,
            .r3dcomments-wrapper-uikit .r3d-reply-btn:focus,
            .r3dcomments-wrapper-standard .r3d-reply-btn:hover,
            .r3dcomments-wrapper-standard .r3d-reply-btn:focus {
                background: rgba(13, 110, 253, 0.14);
                border-color: rgba(13, 110, 253, 0.45);
                color: #084298;
                text-decoration: none;
            }

            .r3dcomments-wrapper-uikit .r3d-submit-btn,
            .r3dcomments-wrapper-standard .r3d-submit-btn {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                min-width: 9rem;
                padding: 0.75rem 1.2rem;
                border: 1px solid #0b5ed7;
                border-radius: 0.85rem;
                background: #0b5ed7;
                color: #fff;
                font-size: 1rem;
                font-weight: 700;
                line-height: 1.2;
                text-decoration: none;
                box-shadow: 0 10px 24px rgba(11, 94, 215, 0.18);
                transition: transform 0.15s ease, box-shadow 0.15s ease, background 0.15s ease, border-color 0.15s ease;
                cursor: pointer;
            }

            .r3dcomments-wrapper-uikit .r3d-submit-btn:hover,
            .r3dcomments-wrapper-uikit .r3d-submit-btn:focus,
            .r3dcomments-wrapper-standard .r3d-submit-btn:hover,
            .r3dcomments-wrapper-standard .r3d-submit-btn:focus {
                background: #084298;
                border-color: #084298;
                color: #fff;
                transform: translateY(-1px);
                box-shadow: 0 12px 28px rgba(11, 94, 215, 0.24);
            }

            .r3dcomments-wrapper-uikit .r3dcomment-form-wrap > h4,
            .r3dcomments-wrapper-standard .r3dcomment-form-wrap > h4 {
                margin-bottom: 1.25rem;
            }

            .r3dcomments-wrapper-uikit .r3dcomment-user-hint,
            .r3dcomments-wrapper-standard .r3dcomment-user-hint {
                margin: -0.5rem 0 1rem;
                color: rgba(0, 0, 0, 0.68);
                font-size: 0.95rem;
            }

            .r3dcomments-wrapper-standard .r3dcomment-item {
                margin: 0 0 1.25rem;
                padding: 1rem;
                border: 1px solid rgba(0, 0, 0, 0.12);
                border-radius: 0.5rem;
                background: #fff;
            }

            .r3dcomments-wrapper-standard .r3dcomment-reply-indicator {
                padding: 0.75rem 1rem;
                border-left: 3px solid #0d6efd;
                background: rgba(13, 110, 253, 0.08);
            }

            .r3dcomments-wrapper-standard #r3dcomment-form button {
                margin-top: 0.5rem;
            }

            #system-message-container.r3d-toast-container {
                position: fixed;
                top: 1rem;
                right: 1rem;
                z-index: 2000;
                width: min(28rem, calc(100vw - 2rem));
                pointer-events: none;
            }

            #system-message-container.r3d-toast-container > * {
                pointer-events: auto;
            }

            #system-message-container.r3d-toast-container joomla-alert,
            #system-message-container.r3d-toast-container .alert {
                margin: 0 0 0.75rem;
                border-radius: 0.9rem;
                box-shadow: 0 18px 40px rgba(0, 0, 0, 0.18);
                animation: r3d-toast-in 0.2s ease-out;
            }

            #system-message-container.r3d-toast-container .r3d-toast-hide {
                animation: r3d-toast-out 0.25s ease-in forwards;
            }

            @keyframes r3d-toast-in {
                from {
                    opacity: 0;
                    transform: translate3d(0, -0.75rem, 0);
                }

                to {
                    opacity: 1;
                    transform: translate3d(0, 0, 0);
                }
            }

            @keyframes r3d-toast-out {
                from {
                    opacity: 1;
                    transform: translate3d(0, 0, 0);
                }

                to {
                    opacity: 0;
                    transform: translate3d(0, -0.5rem, 0);
                }
            }
        </style>
        <?php $r3dcommentsInlineStylesPrinted = true; ?>
    <?php endif; ?>
    <h3><?php echo Text::_('COM_R3DCOMMENTS_COMMENTS_HEADING'); ?></h3>

    <?php if (!empty($items)) : ?>
        <?php foreach ($items as $root) : ?>
            <article class="r3dcomment-item r3dcomment-item-root">
                <header class="r3dcomment-meta">
                    <strong><?php echo htmlspecialchars($root->author_name ?: $root->user_id, ENT_QUOTES, 'UTF-8'); ?></strong>
                    <span> | <?php echo $root->created; ?></span>

                    <?php if ($canEditComment($root)) : ?>
                        <a href="<?php echo Route::_('index.php?option=com_r3dcomments&task=comment.edit&id=' . (int) $root->id); ?>">
                            <?php echo Text::_('JEDIT'); ?>
                        </a>
                    <?php endif; ?>
                </header>

                <div class="r3dcomment-body">
                    <?php echo $root->comment; ?>
                </div>

                <div class="r3dcomment-actions">
                    <a href="#"
                       class="r3d-reply-btn"
                       data-parent="<?php echo (int) $root->id; ?>"
                       data-quote="<?php echo htmlspecialchars(strip_tags($root->comment), ENT_QUOTES, 'UTF-8'); ?>">
                        ↳ <?php echo htmlspecialchars($translateFallback('COM_R3DCOMMENTS_REPLY', 'Antworten', 'Reply'), ENT_QUOTES, 'UTF-8'); ?>
                    </a>
                </div>

                <?php if (!empty($root->children)) : ?>
                    <div class="r3dcomment-children">
                        <?php foreach ($root->children as $child) : ?>
                            <article class="r3dcomment-item r3dcomment-item-child">
                                <header class="r3dcomment-meta">
                                    <strong><?php echo htmlspecialchars($child->author_name ?: $child->user_id, ENT_QUOTES, 'UTF-8'); ?></strong>
                                    <span> | <?php echo $child->created; ?></span>

                                    <?php if ($canEditComment($child)) : ?>
                                        <a href="<?php echo Route::_('index.php?option=com_r3dcomments&task=comment.edit&id=' . (int) $child->id); ?>">
                                            <?php echo Text::_('JEDIT'); ?>
                                        </a>
                                    <?php endif; ?>
                                </header>

                                <div class="r3dcomment-body">
                                    <?php echo $child->comment; ?>
                                </div>

                                <div class="r3dcomment-actions">
                                    <a href="#"
                                       class="r3d-reply-btn"
                                       data-parent="<?php echo (int) $root->id; ?>"
                                       data-quote="<?php echo htmlspecialchars(strip_tags($child->comment), ENT_QUOTES, 'UTF-8'); ?>">
                                        ↳ <?php echo htmlspecialchars($translateFallback('COM_R3DCOMMENTS_REPLY', 'Antworten', 'Reply'), ENT_QUOTES, 'UTF-8'); ?>
                                    </a>
                                </div>
                            </article>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </article>
        <?php endforeach; ?>
    <?php else : ?>
        <p><?php echo Text::_('COM_R3DCOMMENTS_NO_COMMENTS'); ?></p>
    <?php endif; ?>

    <?php if ($form) : ?>
        <div class="r3dcomment-form-wrap">
            <h4><?php echo Text::_('COM_R3DCOMMENTS_WRITE_COMMENT'); ?></h4>
            <?php if (!$user->guest) : ?>
                <p class="r3dcomment-user-hint">
                    <?php echo Text::sprintf(
                        'COM_R3DCOMMENTS_COMMENTING_AS',
                        htmlspecialchars(trim((string) $user->name) !== '' ? $user->name : $user->username, ENT_QUOTES, 'UTF-8')
                    ); ?>
                </p>
            <?php endif; ?>

            <div id="r3d-reply-indicator"
                 class="r3dcomment-reply-indicator"
                 style="display:none;">
                <strong><?php echo Text::_('COM_R3DCOMMENTS_REPLY_TO_COMMENT'); ?></strong>
                <div id="r3d-reply-preview"></div>
                <a href="#" id="r3d-reply-cancel">
                    <?php echo Text::_('JCANCEL'); ?>
                </a>
            </div>

            <form action="<?php echo Uri::root(); ?>index.php?option=com_r3dcomments&task=comment.save"
                  method="post"
                  id="r3dcomment-form">

                <?php foreach ($form->getFieldset('frontend') as $field) : ?>
                    <?php if (($field->fieldname === 'author_name' || $field->fieldname === 'author_email') && !$user->guest) {
                        continue;
                    } ?>
                    <div class="r3dcomment-field">
                        <?php if ($field->fieldname === 'comment') : ?>
                            <div class="control-group">
                                <div class="control-label">
                                    <label id="<?php echo htmlspecialchars($field->id, ENT_QUOTES, 'UTF-8'); ?>-lbl"
                                           for="<?php echo htmlspecialchars($field->id, ENT_QUOTES, 'UTF-8'); ?>"
                                           class="required">
                                        <?php echo htmlspecialchars($translateFallback('COM_R3DCOMMENTS_COMMENT_COMMENT_LBL', 'Kommentar', 'Comment'), ENT_QUOTES, 'UTF-8'); ?><span class="star" aria-hidden="true">&#160;*</span>
                                    </label>
                                </div>
                                <div class="controls">
                                    <?php echo $field->input; ?>
                                </div>
                            </div>
                        <?php else : ?>
                            <?php echo $field->renderField(); ?>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>

                <input type="hidden" name="jform[item_id]" value="<?php echo (int) $itemId; ?>">
                <input type="hidden" name="jform[context]" value="<?php echo htmlspecialchars($context, ENT_QUOTES, 'UTF-8'); ?>">
                <input type="hidden" name="jform[parent_id]" id="r3d-parent" value="0">
                <input type="hidden" name="jform[quoted_comment_id]" id="r3d-quote-id" value="0">
                <input type="hidden" name="jform[quoted_comment_text]" id="r3d-quote-text" value="">
                <input type="hidden" name="jform[state]" value="1">

                <button type="submit" class="r3d-submit-btn">
                    <?php echo Text::_('COM_R3DCOMMENTS_SUBMIT'); ?>
                </button>

                <?php echo HTMLHelper::_('form.token'); ?>
            </form>
        </div>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const replyBox = document.getElementById('r3d-reply-indicator');
    const replyPreview = document.getElementById('r3d-reply-preview');
    const cancelBtn = document.getElementById('r3d-reply-cancel');
    const parentField = document.getElementById('r3d-parent');
    const quoteIdField = document.getElementById('r3d-quote-id');
    const quoteTxtField = document.getElementById('r3d-quote-text');
    const locale = (document.documentElement.lang || 'de').toLowerCase().startsWith('en')
        ? {
            reply: 'Reply',
            commentLabel: 'Comment',
            subscribe: 'Subscribe to article',
            unsubscribe: 'Unsubscribe from article'
        }
        : {
            reply: 'Antworten',
            commentLabel: 'Kommentar',
            subscribe: 'Beitrag abonnieren',
            unsubscribe: 'Beitrag nicht mehr abonnieren'
        };
    const toastMessages = [
        <?php echo json_encode(Text::_('COM_R3DCOMMENTS_DATA_FORM_INFORMATION_RECEIVED')); ?>,
        <?php echo json_encode(Text::_('COM_R3DCOMMENTS_DATA_FORM_INFORMATION_RECEIVED_PENDING')); ?>,
        <?php echo json_encode(Text::_('COM_R3DCOMMENTS_ERROR_GUEST_RATE_LIMIT')); ?>
    ];

    document.querySelectorAll('.r3d-reply-btn').forEach((btn) => {
        const text = btn.textContent.replace(/\s+/g, ' ').trim();

        if (text.includes('COM_R3DCOMMENTS_REPLY')) {
            btn.textContent = '↳ ' + locale.reply;
        }
    });

    const commentLabel = document.querySelector('label[for=\"jform_comment\"]');

    if (commentLabel && commentLabel.textContent.includes('COM_R3DCOMMENTS_COMMENT_COMMENT_LBL')) {
        const starMarkup = commentLabel.querySelector('.star')?.outerHTML || '';
        commentLabel.innerHTML = locale.commentLabel + starMarkup;
    }

    const subscriptionLink = document.querySelector('.r3d-subscription-control a');

    if (subscriptionLink) {
        const text = subscriptionLink.textContent.replace(/\s+/g, ' ').trim();
        const iconMarkup = subscriptionLink.querySelector('span')?.outerHTML || '';
        const shouldLocalize =
            text.includes('Beitrag abonnieren')
            || text.includes('Beitrag nicht mehr abonnieren')
            || text.includes('MOD_R3DCOMMENTS_SUBSCRIBE')
            || text.includes('MOD_R3DCOMMENTS_UNSUBSCRIBE');

        if (shouldLocalize) {
            const localizedText = subscriptionLink.querySelector('.icon-remove')
                ? locale.unsubscribe
                : locale.subscribe;

            subscriptionLink.innerHTML = iconMarkup + ' ' + localizedText;
        }
    }

    document.querySelectorAll('.r3d-reply-btn').forEach((btn) => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();

            const parentId = btn.dataset.parent;
            const quote = btn.dataset.quote;

            parentField.value = parentId;
            quoteIdField.value = parentId;
            quoteTxtField.value = quote;

            replyPreview.innerText = quote;
            replyBox.style.display = 'block';

            document.getElementById('r3dcomment-form').scrollIntoView({ behavior: 'smooth' });
        });
    });

    if (cancelBtn) {
        cancelBtn.addEventListener('click', (e) => {
            e.preventDefault();

            parentField.value = 0;
            quoteIdField.value = 0;
            quoteTxtField.value = '';

            replyPreview.innerText = '';
            replyBox.style.display = 'none';
        });
    }

    const systemMessageContainer = document.getElementById('system-message-container');

    if (systemMessageContainer) {
        const alerts = systemMessageContainer.querySelectorAll('joomla-alert, .alert');
        let matchedAlerts = 0;

        alerts.forEach((alert) => {
            const text = alert.textContent.replace(/\s+/g, ' ').trim();
            const isR3dMessage = toastMessages.some((message) => message && text.includes(message));

            if (!isR3dMessage) {
                return;
            }

            matchedAlerts += 1;

            window.setTimeout(() => {
                alert.classList.add('r3d-toast-hide');
            }, 4200);

            window.setTimeout(() => {
                if (typeof alert.close === 'function') {
                    try {
                        alert.close();
                        return;
                    } catch (error) {
                    }
                }

                alert.remove();
            }, 4550);
        });

        if (matchedAlerts > 0) {
            systemMessageContainer.classList.add('r3d-toast-container');
        }
    }
});
</script>
