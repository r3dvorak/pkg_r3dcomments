<?php
/**
 * @package     mod_r3dcomments
 * @version     6.1.5
 * @copyright   Copyright (C) 2025. All rights reserved.
 * @license     GNU GPL v2 or later
 * @author      Richard Dvořák, <dev@r3d.de> - https://r3d.de
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;

// Layout-Daten vom Helper (item_id + context)
$context = $displayData['context'] ?? 'com_content.article';
$itemId  = (int) ($displayData['item_id'] ?? 0);

if (!$itemId) {
    // Ohne Item-ID macht das Modul nichts
    return;
}

$app  = Factory::getApplication();
$user = $app->getIdentity();

try {
    // Komponente booten und MVC-Factory holen
    /** @var \Joomla\Component\R3dcomments\Site\Extension\R3dcommentsComponent $component */
    $component  = $app->bootComponent('com_r3dcomments');
    $mvcFactory = $component->getMVCFactory();

    /** @var \Joomla\Component\R3dcomments\Site\Model\CommentsModel $commentsModel */
    $commentsModel = $mvcFactory->createModel('Comments', 'Site', ['ignore_request' => true]);
    $commentsModel->setState('filter.context', $context);
    $commentsModel->setState('filter.item_id',  $itemId);
    $items = $commentsModel->getItems();

    /** @var \Joomla\Component\R3dcomments\Site\Model\CommentModel $commentModel */
    $commentModel = $mvcFactory->createModel('Comment', 'Site', ['ignore_request' => true]);
    $form         = $commentModel->getForm();
} catch (\Throwable $e) {
    // Fehler nur im Backend anzeigen
    if ($app->isClient('administrator')) {
        $app->enqueueMessage('R3D Comments module error: ' . $e->getMessage(), 'error');
    }

    return;
}

/**
 * Kleiner ACL-Helper:
 *  - Benutzer darf global editieren ODER
 *  - ist Owner (created_by) UND hat core.edit.own auf Komponentenebene
 */
$canEditComment = function ($comment) use ($user): bool {
    if (!$user || !$user->id) {
        return false;
    }

    // Globaler Edit (Admin, Redakteur etc.)
    if ($user->authorise('core.edit', 'com_r3dcomments')) {
        return true;
    }

    // Eigenen Kommentar bearbeiten dürfen
    if (
        (int) $comment->created_by === (int) $user->id
        && $user->authorise('core.edit.own', 'com_r3dcomments')
    ) {
        return true;
    }

    return false;
};

?>
<div class="r3dcomments-wrapper uk-margin-large-top">


    <h3><?php echo Text::_('COM_R3DCOMMENTS_COMMENTS_HEADING'); ?></h3>

    <?php if (!empty($items)) : ?>

        <?php foreach ($items as $root) : ?>
            <div class="r3dcomment-item uk-card uk-card-default uk-card-body uk-margin">

                <div class="uk-text-small uk-text-muted">
                    <strong><?php echo htmlspecialchars($root->author_name ?: $root->user_id, ENT_QUOTES, 'UTF-8'); ?></strong>
                    <span> • <?php echo $root->created; ?></span>

                    <?php if ($canEditComment($root)) : ?>
                        <a href="<?php echo Route::_('index.php?option=com_r3dcomments&task=comment.edit&id=' . (int) $root->id); ?>"
                           class="uk-text-small uk-margin-small-left">
                            <?php echo Text::_('JEDIT'); ?>
                        </a>
                    <?php endif; ?>
                </div>

                <div class="uk-margin-small-top">
                    <?php echo $root->comment; ?>
                </div>

                <div class="uk-margin-small-top uk-flex uk-flex-between">
                    <div>
                        <a href="#"
                           class="r3d-reply-btn"
                           data-parent="<?php echo (int) $root->id; ?>"
                           data-quote="<?php echo htmlspecialchars(strip_tags($root->comment), ENT_QUOTES, 'UTF-8'); ?>">
                            ↳ <?php echo Text::_('COM_R3DCOMMENTS_REPLY'); ?>
                        </a>
                    </div>
                </div>

                <?php if (!empty($root->children)) : ?>
                    <div class="uk-margin-left uk-margin-small-top">

                        <?php foreach ($root->children as $child) : ?>
                            <div class="uk-card uk-card-small uk-card-body uk-margin-small">

                                <div class="uk-text-small uk-text-muted">
                                    <strong><?php echo htmlspecialchars($child->author_name ?: $child->user_id, ENT_QUOTES, 'UTF-8'); ?></strong>
                                    <span> • <?php echo $child->created; ?></span>

                                    <?php if ($canEditComment($child)) : ?>
                                        <a href="<?php echo Route::_('index.php?option=com_r3dcomments&task=comment.edit&id=' . (int) $child->id); ?>"
                                           class="uk-text-small uk-margin-small-left">
                                            <?php echo Text::_('JEDIT'); ?>
                                        </a>
                                    <?php endif; ?>
                                </div>

                                <div class="uk-margin-small-top">
                                    <?php echo $child->comment; ?>
                                </div>

                                <div class="uk-margin-small-top">
                                    <a href="#"
                                       class="r3d-reply-btn"
                                       data-parent="<?php echo (int) $root->id; ?>"
                                       data-quote="<?php echo htmlspecialchars(strip_tags($child->comment), ENT_QUOTES, 'UTF-8'); ?>">
                                        ↳ <?php echo Text::_('COM_R3DCOMMENTS_REPLY'); ?>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>

                    </div>
                <?php endif; ?>

            </div>
        <?php endforeach; ?>

    <?php else : ?>

        <p><?php echo Text::_('COM_R3DCOMMENTS_NO_COMMENTS'); ?></p>

    <?php endif; ?>

    <?php if ($form) : ?>
        <div class="uk-margin-large-top">
            <h4><?php echo Text::_('COM_R3DCOMMENTS_WRITE_COMMENT'); ?></h4>

            <!-- Reply-Info -->
            <div id="r3d-reply-indicator"
                 class="uk-alert-primary"
                 style="display:none;">
                <strong><?php echo Text::_('COM_R3DCOMMENTS_REPLY_TO_COMMENT'); ?></strong>
                <div id="r3d-reply-preview" class="uk-margin-small-top"></div>
                <a href="#" id="r3d-reply-cancel" class="uk-text-small">
                    <?php echo Text::_('JCANCEL'); ?>
                </a>
            </div>

            <form action="<?php echo Uri::root(); ?>index.php?option=com_r3dcomments&task=comment.save"
                  method="post"
                  id="r3dcomment-form"
                  class="uk-form-stacked uk-margin">

                <?php foreach ($form->getFieldset('frontend') as $field) : ?>
                    <?php
                    // Name / E-Mail nur Gästen anzeigen
                    if (($field->fieldname === 'author_name' || $field->fieldname === 'author_email') && !$user->guest) {
                        continue;
                    }
                    ?>
                    <div class="uk-margin">
                        <?php echo $field->renderField(); ?>
                    </div>
                <?php endforeach; ?>

                <input type="hidden" name="jform[item_id]" value="<?php echo (int) $itemId; ?>">
                <input type="hidden" name="jform[context]" value="<?php echo htmlspecialchars($context, ENT_QUOTES, 'UTF-8'); ?>">
                <input type="hidden" name="jform[parent_id]" id="r3d-parent" value="0">
                <input type="hidden" name="jform[quoted_comment_id]" id="r3d-quote-id" value="0">
                <input type="hidden" name="jform[quoted_comment_text]" id="r3d-quote-text" value="">
                <!-- FIX: angemeldete User direkt veröffentlichen -->
                <input type="hidden" name="jform[state]" value="1">

                <button class="uk-button uk-button-primary uk-margin-small-top">
                    <?php echo Text::_('COM_R3DCOMMENTS_SUBMIT'); ?>
                </button>

                <?php echo HTMLHelper::_('form.token'); ?>
            </form>
        </div>
    <?php endif; ?>

</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const replyBox     = document.getElementById('r3d-reply-indicator');
    const replyPreview = document.getElementById('r3d-reply-preview');
    const cancelBtn    = document.getElementById('r3d-reply-cancel');
    const parentField  = document.getElementById('r3d-parent');
    const quoteIdField = document.getElementById('r3d-quote-id');
    const quoteTxtField= document.getElementById('r3d-quote-text');

    document.querySelectorAll('.r3d-reply-btn').forEach(btn => {
        btn.addEventListener('click', e => {
            e.preventDefault();

            const parentId = btn.dataset.parent;
            const quote    = btn.dataset.quote;

            parentField.value   = parentId;
            quoteIdField.value  = parentId;
            quoteTxtField.value = quote;

            replyPreview.innerText = quote;
            replyBox.style.display = 'block';

            document.getElementById('r3dcomment-form')
                .scrollIntoView({ behavior: 'smooth' });
        });
    });

    if (cancelBtn) {
        cancelBtn.addEventListener('click', e => {
            e.preventDefault();

            parentField.value   = 0;
            quoteIdField.value  = 0;
            quoteTxtField.value = '';

            replyPreview.innerText = '';
            replyBox.style.display = 'none';
        });
    }
});
</script>
