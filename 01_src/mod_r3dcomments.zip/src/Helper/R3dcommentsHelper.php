<?php
/**
 * @package     mod_r3dcomments
 * @version     6.1.3
 * @copyright   Copyright (C) 2025. All rights reserved.
 * @license     GNU GPL v2 or later
 * @author      Richard Dvořák, <dev@r3d.de> - https://r3d.de
 */

namespace R3d\Module\R3dcomments\Site\Helper;

defined('_JEXEC') or die;

use Joomla\CMS\Layout\FileLayout;
use Joomla\CMS\Categories\Categories;

/**
 * Helper-Klasse für das R3D Comments Modul.
 */
class R3dcommentsHelper
{
    /**
     * Prüft alle Bedingungen und gibt den Kommentarblock zurück.
     *
     * @param   object  $item    Das Artikel-Objekt.
     * @param   object  $params  Die Parameter (aus dem Modul).
     *
     * @return  string  Das gerenderte HTML oder ein leerer String.
     */
    public static function renderCommentBlock($item, $params): string
    {
        // Artikel-Objekt validieren
        if (!isset($item->id) || !isset($item->catid)) {
            return '';
        }

        // Kategorien aus den Modul-Parametern lesen
        $allowed = (array) $params->get('allowed_categories', []);

        // Wenn keine Kategorien ausgewählt sind, nichts tun.
        if (empty($allowed)) {
            return '';
        }

        // Kategorie- und Subkategorie-Prüfung
        $includeSubcats = $params->get('include_subcats', 1);
        $isAllowed = in_array((string) $item->catid, $allowed, true);

        // Wenn die direkte Kategorie nicht übereinstimmt UND Unterkategorien eingeschlossen werden sollen
        if (!$isAllowed && (int) $includeSubcats === 1) {
            $categories = Categories::getInstance('content');
            $category = $categories->get($item->catid);

            if ($category) {
                // Prüfen, ob die Kategorie des Artikels ein Kind einer der erlaubten Kategorien ist.
                foreach ($allowed as $allowedCatId) {
                    $parentCategory = $categories->get((int) $allowedCatId);
                    if ($parentCategory) {
                        // getChildren(true) gibt ein flaches Array aller Kind-IDs zurück
                        $childrenIds = array_keys($parentCategory->getChildren(true));
                        if (in_array((int) $item->catid, $childrenIds)) {
                            $isAllowed = true;
                            break; // Schleife beenden, da eine Übereinstimmung gefunden wurde
                        }
                    }
                }
            }
        }

        if (!$isAllowed) {
            return '';
        }

        // Alle Prüfungen bestanden, Layout vorbereiten
        $data = [
            'item_id' => (int) $item->id,
            'context' => 'com_content.article',
        ];

        // Das Layout aus dem tmpl-Verzeichnis des Moduls laden
        $layout = new FileLayout('default', JPATH_BASE . '/modules/mod_r3dcomments/tmpl');
        return $layout->render($data);
    }
}
