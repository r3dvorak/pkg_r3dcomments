<?php
/**
 * @package     mod_r3dcomments
 * @version     6.1.3
 * @copyright   Copyright (C) 2025. All rights reserved.
 * @license     GNU GPL v2 or later
 * @author      Richard Dvořák, <dev@r3d.de> - https://r3d.de
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Helper\ModuleHelper;
use R3d\Module\R3dcomments\Site\Helper\R3dcommentsHelper;
use Joomla\CMS\Router\Route;

// Lade die Sprachdatei der Komponente, damit die Schlüssel übersetzt werden können
Factory::getLanguage()->load('com_r3dcomments', JPATH_SITE);

// Lade die Helper-Klasse, falls der Autoloader sie nicht findet
require_once __DIR__ . '/src/Helper/R3dcommentsHelper.php';

// Prüfen, ob wir uns auf einer Artikelseite befinden
$app   = Factory::getApplication();
$input = $app->input;
$view  = $input->getCmd('view');
$id    = $input->getInt('id');

// Nur ausführen, wenn es sich um eine einzelne Artikelseite handelt
if ($view !== 'article' || !$id) {
    return;
}

// Kategorie-ID des aktuellen Artikels direkt aus der Datenbank laden, um ACL-Probleme zu umgehen.
try {
    $db = Factory::getDbo();
    $query = $db->getQuery(true)
        ->select($db->quoteName('catid'))
        ->from($db->quoteName('#__content'))
        ->where($db->quoteName('id') . ' = ' . (int) $id);
    $catid = $db->setQuery($query)->loadResult();
} catch (\Exception $e) {
    // Bei einem DB-Fehler abbrechen
    return;
}

// Erstellen eines einfachen Objekts, das die renderCommentBlock-Methode erwartet.
$itemObject = (object) ['id' => $id, 'catid' => $catid];

// --- NEU: Abonnement-Button/Link anzeigen ---
$user = Factory::getUser();

// Nur für angemeldete Benutzer anzeigen
if (!$user->guest) {
    $db = Factory::getDbo();
    $query = $db->getQuery(true)
        ->select('COUNT(*)')
        ->from($db->quoteName('#__r3dcomments_subscriptions'))
        ->where($db->quoteName('user_id') . ' = ' . (int) $user->id)
        ->where($db->quoteName('context') . ' = ' . $db->quote('com_content.article'))
        ->where($db->quoteName('item_id') . ' = ' . (int) $id);

    $db->setQuery($query);
    $isSubscribed = (bool) $db->loadResult();

    $subscribeUrl = Route::_('index.php?option=com_r3dcomments&task=comment.toggleSubscription&context=com_content.article&item_id=' . $id);
    
    $subscribeText = $isSubscribed ? 'Beitrag nicht mehr abonnieren' : 'Beitrag abonnieren';
    $subscribeIcon = $isSubscribed ? 'icon-remove' : 'icon-plus'; // Joomla 4/5: 'icon-minus', 'icon-plus'

    echo '<div class="r3d-subscription-control" style="margin-bottom: 15px;">';
    echo '  <a href="' . $subscribeUrl . '" class="btn">';
    echo '    <span class="' . $subscribeIcon . '" aria-hidden="true"></span> ';
    echo      $subscribeText;
    echo '  </a>';
    echo '</div>';
}
// --- Ende: Abonnement-Button/Link ---

// Die statische Render-Funktion des Helpers aufrufen und das Ergebnis ausgeben
// $params ist eine magische Variable, die vom ModuleHelper bereitgestellt wird
echo R3dcommentsHelper::renderCommentBlock($itemObject, $params);
