<?php
/**
 * @package     com_r3dcomments
 * @version     5.1.1
 * @copyright   Copyright (C) 2025. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Richard Dvořák, <dev@r3d.de> - https://r3d.de
 */

namespace Joomla\Component\R3dcomments\Site\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\FormController;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Crypt\Crypt;
use RuntimeException;

/**
 * R3dcomments front-end comment controller
 */
class CommentController extends FormController
{
    /**
     * The list view to use after save
     *
     * @var string
     */
    protected $view_list = 'comments';

    /**
     * Method to display the edit form.
     *
     * @param   string  $cachable   If true, the view output will be cached.
     * @param   array   $urlparams  An array of safe url parameters and their variable types.
     *
     * @return  void
     *
     * @since   5.2.7
     */
    public function edit($key = null, $urlVar = 'id')
    {
        // Hole Joomla Application
        $app = $this->app ?? Factory::getApplication();

        // Kommentar-ID aus der URL
        $id = $app->getInput()->getInt('id');

        if (!$id) {
            throw new \RuntimeException('Missing comment id', 400);
        }

        // Model holen
        /** @var \Joomla\Component\R3dcomments\Site\Model\CommentModel $model */
        $model = $this->getModel('Comment');

        // VERY IMPORTANT: State korrekt setzen
        $model->setState('comment.id', $id);

        // Sichten definieren
        $this->view_item = 'comment';
        $this->view_list = 'comments';

        // Standardanzeige durchführen
        return parent::display();
    }

    /**
     * Handle saving of a comment from the front-end form.
     *
     * This replaces the old sendInformation() logic and is called via:
     * index.php?option=com_r3dcomments&task=comment.save
     *
     * @param  string|null $key
     * @param  string      $urlVar
     *
     * @return void
     */
    public function save($key = null, $urlVar = 'id'): void
    {
        // CSRF check
        if (!Session::checkToken('post'))
        {
            throw new RuntimeException(Text::_('JINVALID_TOKEN'), 403);
        }

        $app   = $this->app ?? Factory::getApplication();
        $input = $app->getInput();
        $user  = $app->getIdentity();

        // Get POSTed data
        $data = (array) $input->post->get('jform', [], 'array');

        // Ensure we have context & item_id (from hidden fields / plugin)
        $context          = $data['context'] ?? $input->getString('context', 'com_content.article');
        $itemId           = (int) ($data['item_id'] ?? $input->getInt('item_id', 0));
        $data['context']  = $context;
        $data['item_id']  = $itemId;

        // Fallback redirect URL: back to the article
        $redirectUrl = Route::_('index.php?option=com_content&view=article&id=' . $itemId, false);

        /** @var \Joomla\Component\R3dcomments\Site\Model\CommentModel $model */
        $model = $this->getModel('Comment');

        // Form validation (JForm rules)
        $form = $model->getForm($data, false);

        if (!$form)
        {
            $app->enqueueMessage(Text::_('COM_R3DCOMMENTS_ERROR_FORM_NOT_AVAILABLE'), 'error');
            $this->setRedirect($redirectUrl);

            return;
        }

        // Validierung (mit unserer angepassten Logik im Model)
        if (!$model->validate($form, $data))
        {
            $errors = $model->getErrors();

            foreach ($errors as $error)
            {
                $message = $error instanceof \Exception ? $error->getMessage() : (string) $error;
                $app->enqueueMessage($message, 'error');
            }

            $this->setRedirect($redirectUrl);

            return;
        }

        // Try to save using our model logic
        try
        {
            // Moderations-Token für die E-Mail-Links generieren
            $data['moderation_token'] = bin2hex(Crypt::genRandomBytes(20)); // 40-stelliger Token

            $id = $model->save($data);

            // Benachrichtigungen an Abonnenten senden, wenn der Kommentar veröffentlicht ist
            if (!empty($data['state']) && (int) $data['state'] === 1)
            {
                $this->sendSubscriptionEmails($id, (int) $user->id);
            }

            // E-Mail-Benachrichtigung senden
            $componentParams = Factory::getApplication()->getParams('com_r3dcomments');
            $recipient       = $componentParams->get('recipient_email');

            if (!empty($recipient))
            {
                $config = Factory::getConfig(); // Globale Joomla-Konfig für Mailer-Sender
                $mailer = Factory::getMailer();

                // Moderations-Links erstellen
                $baseUri    = Uri::root();
                $publishUrl = $baseUri . 'index.php?option=com_r3dcomments&task=comment.moderate&id=' . $id . '&token=' . $data['moderation_token'] . '&action=publish';
                $trashUrl   = $baseUri . 'index.php?option=com_r3dcomments&task=comment.moderate&id=' . $id . '&token=' . $data['moderation_token'] . '&action=trash';
                $backendUrl = $baseUri . 'administrator/index.php?option=com_r3dcomments&task=comment.edit&id=' . $id;

                // Betreff und Body aus der Konfiguration holen
                $defaultSubject = 'New comment on {site_name}';
                $defaultBody    = "A new comment has been posted on the website.\n\nAuthor: {author_name}\nE-Mail: {author_email}\nComment:\n{comment}\n\nActions:\nPublish: {publish_url}\nTrash: {trash_url}\n\nEdit in backend:\n{backend_url}";

                $subjectTemplate = $componentParams->get('email_subject', $defaultSubject);
                $bodyTemplate    = $componentParams->get('email_body', $defaultBody);

                // Platzhalter-Daten vorbereiten
                $replacements = [
                    '{site_name}'    => $config->get('sitename'),
                    '{author_name}'  => $user->guest ? ($data['author_name'] ?? 'Gast') : $user->name,
                    '{author_email}' => $user->guest ? ($data['author_email'] ?? 'N/A') : $user->email,
                    '{comment}'      => $data['comment'] ?? '',
                    '{publish_url}'  => $publishUrl,
                    '{trash_url}'    => $trashUrl,
                    '{backend_url}'  => $backendUrl,
                ];

                $subject = str_replace(array_keys($replacements), array_values($replacements), $subjectTemplate);
                $body    = str_replace(array_keys($replacements), array_values($replacements), $bodyTemplate);

                $mailer->setSender([
                    $config->get('mailfrom'),
                    $config->get('fromname')
                ]);
                $mailer->addRecipient($recipient);
                $mailer->setSubject($subject);
                $mailer->setBody($body);
                $mailer->send();
            }
        }
        catch (RuntimeException $e)
        {
            $app->enqueueMessage($e->getMessage(), 'error');
            $this->setRedirect($redirectUrl);

            return;
        }

        // Erfolgsmeldung
        $this->setMessage(Text::_('COM_R3DCOMMENTS_DATA_FORM_INFORMATION_RECEIVED'));
        $this->setRedirect($redirectUrl);
    }

    /**
     * Send email notifications to all subscribers of a content item.
     */
    protected function sendSubscriptionEmails(int $commentId, int $authorId): void
    {
        $db = Factory::getDbo();
        
        // Kommentar-Details laden
        $commentQuery = $db->getQuery(true)
            ->select('a.comment, a.context, a.item_id, a.author_name AS guest_author_name')
            ->from($db->quoteName('#__r3dcomments', 'a'))
            ->where('a.id = ' . $commentId);
        $db->setQuery($commentQuery);
        $comment = $db->loadObject();

        if (!$comment) {
            return;
        }

        // Abonnenten laden (außer dem Autor des Kommentars)
        $subscribersQuery = $db->getQuery(true)
            ->select('u.email, u.name')
            ->from($db->quoteName('#__r3dcomments_subscriptions', 's'))
            ->join('INNER', $db->quoteName('#__users', 'u') . ' ON s.user_id = u.id')
            ->where('s.context = ' . $db->quote($comment->context))
            ->where('s.item_id = ' . (int) $comment->item_id)
            ->where('s.user_id <> ' . (int) $authorId);
        
        $db->setQuery($subscribersQuery);
        $subscribers = $db->loadObjectList();

        if (empty($subscribers)) {
            return;
        }

        $config    = Factory::getConfig();
        $mailer    = Factory::getMailer();
        $authorUser = Factory::getUser($authorId);
        $authorName = $authorUser->guest ? $comment->guest_author_name : $authorUser->name;

        $articleUrl = Uri::root() . Route::_(
            'index.php?option=' . $comment->context . '&id=' . $comment->item_id,
            false
        );

        $subject = 'Neuer Kommentar zum Beitrag';
        $body = "Hallo {recipient_name},\n\n"
              . "Ein neuer Kommentar wurde von '{author_name}' zum Beitrag, den Sie abonniert haben, hinzugefügt:\n\n"
              . "--------------------------------------------------\n"
              . "{comment}\n"
              . "--------------------------------------------------\n\n"
              . "Sie können den Beitrag hier ansehen:\n"
              . "{article_url}";

        foreach ($subscribers as $subscriber) {
            $replacements = [
                '{recipient_name}' => $subscriber->name,
                '{author_name}'    => $authorName,
                '{comment}'        => $comment->comment,
                '{article_url}'    => $articleUrl,
            ];
            $emailBody = str_replace(array_keys($replacements), array_values($replacements), $body);

            $mailer->clearAllRecipients();
            $mailer->setSender([$config->get('mailfrom'), $config->get('fromname')]);
            $mailer->addRecipient($subscriber->email);
            $mailer->setSubject($subject);
            $mailer->setBody($emailBody);
            $mailer->send();
        }
    }

    public function toggleSubscription(): void
    {
        $app  = Factory::getApplication();
        $user = Factory::getUser();

        if ($user->guest) {
            $app->enqueueMessage('Nur angemeldete Benutzer können Abonnements verwalten.', 'error');
            $this->setRedirect(Route::_('index.php'));
            return;
        }

        $context = $this->input->getString('context');
        $itemId  = $this->input->getInt('item_id');

        // Aktiven Menüpunkt / passenden Itemid finden
        $menu   = $app->getMenu();
        $active = $menu->getActive();

        if ($active && $active->query['option'] === 'com_content') {
            $realItemid = $active->id;
        } else {
            $realItemid = $this->findItemIdForArticle($itemId);
        }

        $redirectUrl = Route::_(
            'index.php?option=com_content&view=article&id=' . $itemId . '&Itemid=' . $realItemid
        );

        /** @var \Joomla\Component\R3dcomments\Site\Model\SubscriptionModel $model */
        $model = $this->getModel('Subscription');

        try {
            $isSubscribed = $model->toggleSubscription($user->id, $context, $itemId);
            $message = $isSubscribed
                ? 'Sie haben diesen Beitrag abonniert.'
                : 'Sie haben das Abonnement für diesen Beitrag beendet.';

            $app->enqueueMessage($message, 'message');
        } catch (\Exception $e) {
            $app->enqueueMessage('Fehler beim Ändern des Abonnements: ' . $e->getMessage(), 'error');
        }

        $this->setRedirect($redirectUrl);
    }

    protected function findItemIdForArticle(int $articleId): int
    {
        $db    = Factory::getDbo();
        $query = $db->getQuery(true)
            ->select('id')
            ->from('#__menu')
            ->where("CONCAT_WS(',', link, query) LIKE " . $db->quote('%id=' . $articleId . '%'))
            ->where('type = ' . $db->quote('component'))
            ->where('published = 1')
            ->order('id ASC');

        $db->setQuery($query);
        return (int) $db->loadResult();
    }

    public function moderate(): void
    {
        $app   = $this->app ?? Factory::getApplication();
        $input = $app->getInput();

        $id     = $input->getInt('id');
        $token  = $input->getString('token');
        $action = $input->getString('action');

        if (!$id || !$token || !$action)
        {
            $app->enqueueMessage(Text::_('COM_R3DCOMMENTS_MODERATION_INVALID_LINK'), 'error');
            $this->setRedirect(Route::_('index.php'));
            return;
        }

        /** @var \Joomla\Component\R3dcomments\Site\Model\CommentModel $model */
        $model   = $this->getModel('Comment');
        $comment = $model->getItem($id);

        if (!$comment || empty($comment->moderation_token) || !hash_equals($comment->moderation_token, $token))
        {
            $app->enqueueMessage(Text::_('COM_R3DCOMMENTS_MODERATION_LINK_INVALID_OR_USED'), 'error');
            $this->setRedirect(Route::_('index.php'));
            return;
        }

        $newState = null;
        $message  = '';

        if ($action === 'publish')
        {
            $newState = 1;
            $message  = Text::_('COM_R3DCOMMENTS_MODERATION_PUBLISH_SUCCESS');
        }
        elseif ($action === 'trash')
        {
            $newState = -2;
            $message  = Text::_('COM_R3DCOMMENTS_MODERATION_TRASH_SUCCESS');
        }

        if ($newState !== null)
        {
            $model->publish([$id], $newState);
            $app->enqueueMessage($message, 'message');
        }

        $this->setRedirect(Route::_('index.php'));
    }
}
