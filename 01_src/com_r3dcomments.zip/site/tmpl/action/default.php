<?php
/**
 * @package     mod_r3dcomments
 * @version     6.1.7
 * @copyright   Copyright (C) 2025. All rights reserved.
 * @license     GNU GPL v2 or later
 * @author      Richard Dvořák, <dev@r3d.de> - https://r3d.de
 */
// Empty view for action tasks — required for Joomla router stability.
echo '';
