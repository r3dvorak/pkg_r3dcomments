DROP TABLE IF EXISTS `#__r3dcomments`;
DROP TABLE IF EXISTS `#__r3dcomments_subscriptions`;